from docx import Document

def docx_info(file_path):
    """
    Extract metadata from a Word document (.docx).
    """
    
    metadata = {}
    
    # Open the document
    try:
        doc = Document(file_path)
    except Exception as e:
        return {"error": str(e)}
    
    # Extract core properties
    core_properties = doc.core_properties
    metadata["title"] = core_properties.title
    metadata["author"] = core_properties.author
    metadata["category"] = core_properties.category
    metadata["identifier"] = core_properties.identifier
    metadata["language"] = core_properties.language
    
    return metadata

