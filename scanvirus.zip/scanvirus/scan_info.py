import subprocess
import re
import json
import os
import redis
def general_info(filepath):
	r = redis.Redis(host='localhost', port=6379, decode_responses=True)
	tlsh_info = ["./tlsh-master/bin/tlsh","-f", filepath]
	md5_info = ["md5sum",filepath]
	sha256_info = ["sha256sum",filepath]
	trid_info = ["./trid_linux/trid",filepath]
	ssdeep_info = ["/usr/bin/ssdeep",filepath]
	general_info = ["exiftool",filepath]
	list_info = ["tlsh_info","md5_info","sha256_info","trid_info","ssdeep_info","general_info"]
	data = {}
	data["scan_pe"] = {}
	try:
    		filesize = os.path.getsize(filepath)
    		data["filename"] = ""
    		data["filesize"] = filesize
    		for info in list_info:
    			if info == "tlsh_info":
    				result = subprocess.run(tlsh_info, capture_output=True, text=True, check=True)
    				result = str(result.stdout).rstrip()
    				data["tlsh"] = re.split(r'\s+',result)[0]
    			elif info == "md5_info":
    				result = subprocess.run(md5_info, capture_output=True, text=True, check=True)
    				result = str(result.stdout).rstrip()
    				data["md5"] = re.split(r'\s+',result)[0]
    			elif info == 'sha256_info':
    				result = subprocess.run(sha256_info, capture_output=True, text=True, check=True)
    				result = str(result.stdout).rstrip()
    				data["sha256"] = re.split(r'\s+',result)[0]
    			elif info == 'trid_info':
    				pattern = r"\d+\.\d%.+\d\)"
    				trid = ""
    				result = subprocess.run(trid_info, capture_output=True, text=True, check=True)
    				result = str(result.stdout).rstrip()
    				list_filetype = re.findall(pattern, result)
    				for i in range(len(list_filetype)):
    					if i != len(list_filetype)-1:
    						trid += list_filetype[i] + " | "
    					else:
    						trid += list_filetype[i]
    				data["trid"] = trid
    			elif info == 'ssdeep_info':
    				result = subprocess.run(ssdeep_info, capture_output=True, text=True, check=True)
    				result = str(result.stdout).rstrip()
    				temp = result.split('\n')
    				ssdeep = temp[1].split(',')
    				data["ssdeep"] = ssdeep[0]
    			elif info == 'general_info':
    				general_info_list = ["File Type","MIME Type"]
    				result = subprocess.run(general_info, capture_output=True, text=True, check=True)
    				for line in result.stdout.splitlines():
    					key_value = re.split(r'\s+:\s',line)
    					if key_value[0] in general_info_list:
    						data[key_value[0]] = key_value[1] 
    				
    		return data
	except subprocess.CalledProcessError as e:
    		return "ERROR"
