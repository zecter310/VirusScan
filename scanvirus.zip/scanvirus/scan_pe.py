import base64
import binascii
import datetime
import hashlib
import json
import logging
import struct
from io import BytesIO
import pefile

def pe_info(filepath):
	data = {}
	CHARACTERISTICS_DLL = {
    		0x0020: "HIGH_ENTROPY_VA",
    		0x0040: "DYNAMIC_BASE",
    		0x0080: "FORCE_INTEGRITY",
    		0x0100: "NX_COMPAT",
    		0x0200: "NO_ISOLATION",
    		0x0400: "NO_SEH",
    		0x0800: "NO_BIND",
    		0x1000: "APPCONTAINER",
    		0x2000: "WDM_DRIVER",
    		0x4000: "GUARD_CF",
   		0x8000: "TERMINAL_SERVER_AWARE",
	}
	CHARACTERISTICS_IMAGE = {
    		0x0001: "RELOCS_STRIPPED",
		0x0002: "EXECUTABLE_IMAGE",
   		0x0004: "LINE_NUMS_STRIPPED",
    		0x0008: "LOCAL_SYMS_STRIPPED",
    		0x0010: "AGGRESIVE_WS_TRIM",
    		0x0020: "LARGE_ADDRESS_AWARE",
    		0x0040: "16BIT_MACHINE",
    		0x0080: "BYTES_REVERSED_LO",
    		0x0100: "32BIT_MACHINE",
    		0x0200: "DEBUG_STRIPPED",
    		0x0400: "REMOVABLE_RUN_FROM_SWAP",
    		0x0800: "NET_RUN_FROM_SWAP",
    		0x1000: "SYSTEM",
    		0x2000: "DLL",
    		0x4000: "UP_SYSTEM_ONLY",
    		0x8000: "BYTES_REVERSED_HI",
	}

	event = {}
	f = open(filepath,"rb")
	data = f.read()
	pe = pefile.PE(data=data)

	event["base_of_code"] = str(hex(pe.OPTIONAL_HEADER.BaseOfCode))
	event["address_of_entry_point"] = str(hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint))
	event["image_base"] = str(hex(pe.OPTIONAL_HEADER.ImageBase))
	event["size_of_code"] = pe.OPTIONAL_HEADER.SizeOfCode
	event["size_of_initialized_data"] = pe.OPTIONAL_HEADER.SizeOfInitializedData
	event["size_of_headers"] = pe.OPTIONAL_HEADER.SizeOfHeaders
	event["size_of_image"] = pe.OPTIONAL_HEADER.SizeOfImage
	event["linker_version"] = float(f"{pe.OPTIONAL_HEADER.MajorLinkerVersion}.{pe.OPTIONAL_HEADER.MinorLinkerVersion}")
	event["operating_system_version"] = float(f"{pe.OPTIONAL_HEADER.MajorOperatingSystemVersion}.{pe.OPTIONAL_HEADER.MinorOperatingSystemVersion}")
#event["compile_time"] = datetime.datetime.utcfromtimestamp(pe.FILE_HEADER.TimeDateStamp).isoformat()
	dll_characteristics = []
	for o in CHARACTERISTICS_DLL:
		if pe.OPTIONAL_HEADER.DllCharacteristics & o:
			dll_characteristics.append(CHARACTERISTICS_DLL[o])
	if dll_characteristics:
		event["dll_characteristics"] = dll_characteristics

	image_characteristics = []
	for o in CHARACTERISTICS_IMAGE:
		if pe.FILE_HEADER.Characteristics & o:
			image_characteristics.append(CHARACTERISTICS_IMAGE[o])
	if image_characteristics:
		event["image_characteristics"] = image_characteristics
	section_list = [".text",".data",".reloc"]
	section_dict = {".text":{},".data":{},".reloc":{}}
	for section in pe.sections:
		section_name = section.Name.decode().replace("\x00","")
		if section_name in section_list:
			section_dict[section_name]["Virtual Address"] = str(hex(section.VirtualAddress))
			section_dict[section_name]["Virtual Size"] = str(hex(section.Misc_VirtualSize))
			section_dict[section_name]["Raw Size"] = str(hex(section.SizeOfRawData))
	event["sections"] = section_dict
	return event
