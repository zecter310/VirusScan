import fitz  # PyMuPDF
import io
from datetime import datetime
import re


def pdf_info(filepath):
	f = open(filepath,'rb')
	event = {}
	data = f.read()
	
	def time_format(string_time):
		if "D" in string_time:
			string_time = string_time[2:]
		date_utc = string_time.split('+')
		date = date_utc[0]
		date = datetime.strptime(date, "%Y%m%d%H%M%S")
		if len(date_utc) > 1:
			utc = date_utc[1]
			utc = utc.split("'")[:-1]
			utc = ":".join(utc)
			date_utc = str(date) + "+" + utc
		else:
			date_utc = str(date)
		return date_utc

	with io.BytesIO(data) as pdf_io:
		reader = fitz.open(stream=pdf_io, filetype="pdf")

	event["author"] = reader.metadata["author"]
	event["creator"] = reader.metadata["creator"]
	event["creation_date"] = time_format(reader.metadata["creationDate"])
	event["modify_date"] = time_format(reader.metadata["modDate"])
	event["dirty"] = reader.is_dirty
	event["encrypted"] = reader.is_encrypted
	event["needs_pass"] = reader.needs_pass
	event["pages"] = reader.page_count
	event["keyword"] = reader.metadata["keywords"]
	event["repaired"] = reader.is_repaired
	event["xrefs"] = reader.xref_length()-1
	
	if reader.is_encrypted:
		return event
	event["images"] = 0
	event["links"] = []
	
	event["embedded_files"] = {
		"count": reader.embfile_count(),
		"names": reader.embfile_names()
	}
	text = ""
	for page in reader:
		for link in page.get_links():
			event["links"].append(link.get("uri"))
		text += page.get_text()
		event["links"].extend(re.findall(r"https?://[^\s)>]+", text))
	if event["links"]:
		event["links"] = list(set(filter(None, event["links"])))
	return event
filepath = "/home/kali/Downloads/sample_2.pdf"
print(pdf_info(filepath))
