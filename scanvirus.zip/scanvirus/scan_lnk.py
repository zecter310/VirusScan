import LnkParse3

filepath = "/home/kali/Desktop/scanvirus/sample/sample_3.lnk"

with open(filepath,'rb') as file:

	lnk = LnkParse3.lnk_file(file)

result = lnk.print_json()
print(type(result))
