import subprocess
import re
import json

def ole_info(filepath):
	data = {"scan_oledump":{},"scan_olevba":{}}
	#oledump
	oledump_scan = ["./oledump.py",filepath]
	clean_pattern = r"\\x\d+"
	result = subprocess.run(oledump_scan, capture_output=True, text=True, check=False)
	result = str(result.stdout).rstrip()
	result = re.sub(clean_pattern, "",result)
	pattern_size = r"\s(\d+)\s"
	pattern_ole = r"'(\S+)'"
	list_size = re.findall(pattern_size,result)
	list_ole = re.findall(pattern_ole,result)
	oledict = {}
	for i in range(len(list_size)):
		oledict[list_ole[i]] = int(list_size[i])
	data["scan_oledump"] = oledict
	#olevba
	olevba_scan = ["olevba","-a","-j",filepath]
	with open('output.json','w') as output_file:
		subprocess.run(olevba_scan, stdout=output_file, stderr=subprocess.PIPE)
	with open('output.json','r') as file:
		olevba_result = json.load(file)
	temp = {}
	count = 0
	for item in olevba_result[1]['analysis']:
		temp[count+1] = item
		count += 1
	remove_json = ["rm","output.json"]
	remove = subprocess.run(remove_json, capture_output=True, text=True, check=False)
	data["scan_olevba"] = temp
	return data

