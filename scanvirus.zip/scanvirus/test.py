import subprocess
import re
import json
import fitz  # PyMuPDF
import io
from datetime import datetime

filepath = "/home/kali/Downloads/sample_2.pdf"
f = open(filepath,'rb')
event = {}
data = f.read()
with io.BytesIO(data) as pdf_io:
	reader = fitz.open(stream=pdf_io, filetype="pdf")

temp = reader.metadata["creationDate"]
print(temp)
