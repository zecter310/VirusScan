from flask import Flask, request, render_template, redirect, url_for, jsonify
import os
import socket
import threading
import json
import subprocess
import redis
import re
import time
from scan_info import general_info
from scan_pe import pe_info
from scan_pdf import pdf_info
from scan_docx import docx_info
from scan_ole import ole_info

app = Flask(__name__)
REPORTS_FOLDER = 'reports'
UPLOAD_FOLDER = 'uploads'
HISTORY_FOLDER = 'history'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/delete_reports', methods=['POST'])
def delete_reports():
    try:
        # Đường dẫn thư mục chứa báo cáo
        reports_dir = "/home/kali/Desktop/scanvirus/reports/"
        # Xóa tất cả các file trong thư mục báo cáo
        for filename in os.listdir(reports_dir):
            file_path = os.path.join(reports_dir, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
        return {"status": "success", "message": "All reports deleted."}, 200
    except Exception as e:
        return {"status": "error", "message": str(e)}, 500

# Hàm gửi tên file tới máy Windows qua netcat
def send_file_name_to_windows(file_name):
    try:
        # Kết nối tới Windows qua Netcat (có thể thay đổi địa chỉ IP và cổng)
        #with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            #s.connect(('10.81.36.10', 9999))  # Địa chỉ IP và cổng máy Windows
            #s.sendall(file_name.encode())  # Gửi tên file
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(('10.81.36.30', 9999))  # Địa chỉ IP và cổng máy Windows
            s.sendall(file_name.encode())
    except Exception as e:
        print(f"Error sending file name: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def upload_file():
    file = request.files['file']
    if file:
        filename = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filename)
        return render_template('index.html', file_name=file.filename)
        
@app.route('/upload', methods=['POST'])
def upload_report():
    # Kiểm tra nếu không có file trong request
    if 'file' not in request.files:
        return jsonify({"error": "No file part in the request"}), 400

    file = request.files['file']

    # Kiểm tra nếu file không có tên
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    # Lưu file
    try:
    	#if file.filename contains "history"
        filepath = os.path.join(REPORTS_FOLDER, file.filename)
        file.save(filepath)
        return jsonify({"message": "File uploaded successfully", "filename": file.filename}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/scan', methods=['POST'])
def scan_file():
	filename = request.form['file_name']
	filepath = os.path.join(UPLOAD_FOLDER, filename)
	file_name = "Download: " + filename
	r = redis.Redis(host='localhost', port=6379, decode_responses=True)
	data = general_info(filepath)
	data["filename"] = filename
	if 'exe' in data["File Type"].lower():
		peinfo = pe_info(filepath)
		data["scan_pe"] = peinfo
	elif 'docx' in data["File Type"].lower():
		if '(.DOCX)' in data['trid']:
			docxinfo = docx_info(filepath)
			data["scan_docx"] = docxinfo
		elif '(.DOC)' in data['trid']:
			oleinfo = ole_info(filepath)
			data["scan_ole"] = oleinfo
	elif 'pdf' in data["File Type"].lower():
		pdfinfo = pdf_info(filepath)
		data["scan_pdf"] = pdfinfo
	
	r.set("scan_data",json.dumps(data))
    # Tạo một thread để gửi tên file tới máy Windows qua Netcat
	threading.Thread(target=send_file_name_to_windows, args=(file_name,)).start()
	return redirect(url_for('scan_report'))
def check_report_status():
	ENGINES = ["Windows_Defender"]
	
	status = True
	for eng in ENGINES:
		report_filename = f"{eng}_report.txt"
		report_path = "/home/kali/Desktop/scanvirus/reports/" + report_filename
		if os.path.exists(report_path) == False:
			status = False
			break
	if status:
		r = redis.Redis(host='localhost', port=6379, decode_responses=True)
		data = json.loads(r.get("scan_data"))
		for eng in ENGINES:
			report_filename = f"{eng}_report.txt"
			report_path = "/home/kali/Desktop/scanvirus/reports/" + report_filename
			with open(report_path,'r') as file:
				for line in file:
					tmp = line.strip()
					result = tmp.split(': ')
					if len(result) > 1:
						if "duration" in result[0]:
							data["duration"] = result[1]
						elif "ts_start" in result[0]:
							data["ts_start_scan"] = result[1]
						elif "ts_end" in result[0]:
							data["ts_end_scan"] = result[1]
						elif "Kaspersky" in result[0] or "Defender" in result[0]:
							data[str(eng)] = result[1]
		
		return data
		
	else:
		time.sleep(2)
		return check_report_status()



@app.route('/scan_report')
def scan_report():
    return render_template('scan_report.html')
    
@app.route('/get_report_status')
def get_report_status():
    """Endpoint trả về trạng thái quét dưới dạng JSON."""
    #status = get_engine_report_status()
    status = check_report_status()
    return jsonify(status)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
